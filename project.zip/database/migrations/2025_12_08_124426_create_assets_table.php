<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    //Demirbaşlar tablosu
    public function up(): void
    {
        Schema::create('assets', function (Blueprint $table) {
            $table->id();
            $table->foreignId('location_id')->nullable()->constrained()->nullOnDelete();

            $table->string('name'); // Buzdolabı
            $table->string('brand')->nullable(); // Arçelik
            $table->string('serial_number')->nullable();

            $table->date('purchase_date')->nullable();
            $table->date('warranty_expiration')->nullable();

            $table->string('status')->default('active'); // active, broken, repair

            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('assets');
    }
};
