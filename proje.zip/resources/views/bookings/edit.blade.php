@extends('layouts.app')

@section('title', 'Rezervasyon Düzenle')

@section('content')
    <div class="container py-4">

        {{-- 1. PHP Mantığı: Verileri Hazırla --}}
        @php
            $backRoute = '#';
            $planTitle = 'Belirsiz Plan';
            $contextLabel = 'Bağlı Olduğu Plan';

            if ($booking->bookable) {
                if ($booking->bookable_type === 'App\Models\Travel') {
                    $backRoute = route('travels.show', $booking->bookable_id);
                    $planTitle = $booking->bookable->title ?? 'İsimsiz Seyahat';
                    $contextLabel = 'Seyahat';
                } else {
                    $backRoute = route('service.events.show', $booking->bookable_id);
                    $planTitle = $booking->bookable->name ?? 'İsimsiz Etkinlik';
                    $contextLabel = 'Etkinlik';
                }
            }
        @endphp

        <div class="row justify-content-center">
            <div class="col-lg-10">

                {{-- 2. Üst Başlık Alanı (Header dışında, sade metin) --}}
                <div class="d-flex justify-content-between align-items-end mb-4">
                    <div>
                        <h6 class="text-uppercase text-muted fw-bold mb-1" style="font-size: 0.75rem; letter-spacing: 1px;">
                            {{ $contextLabel }} YÖNETİMİ
                        </h6>
                        <h2 class="fw-bold text-dark mb-0">Rezervasyon Düzenle</h2>
                        <div class="d-flex align-items-center text-secondary mt-2">
                            <i class="fa-solid fa-layer-group me-2"></i>
                            <span>{{ $planTitle }}</span>
                        </div>
                    </div>
                    <div>
                        <a href="{{ $backRoute }}" class="btn btn-light border bg-white shadow-sm text-muted">
                            <i class="fa-solid fa-arrow-left me-1"></i> Vazgeç ve Dön
                        </a>
                    </div>
                </div>

                {{-- 3. Ana Form Kartı --}}
                <div class="card border-0 shadow-sm rounded-3">
                    {{-- Üst kısma ince bir renkli çizgi (Kurumsal Mavi) --}}
                    <div class="card-header bg-white border-0 pt-0"></div>
                    <div class="card-body p-4 p-md-5">

                        <form action="{{ route('bookings.update', $booking) }}" method="POST"
                            enctype="multipart/form-data">
                            @csrf
                            @method('PUT')

                            {{-- Form Parçası --}}
                            @include('bookings._form', ['booking' => $booking])

                            <hr class="my-4 text-muted opacity-25">

                            {{-- Alt Aksiyon Butonları --}}
                            <div class="d-flex justify-content-end align-items-center gap-2">
                                <a href="{{ $backRoute }}" class="btn btn-link text-decoration-none text-muted">
                                    İptal
                                </a>
                                <button type="submit" class="btn btn-primary px-4 py-2 fw-medium">
                                    <i class="fa-regular fa-floppy-disk me-2"></i> Değişiklikleri Kaydet
                                </button>
                            </div>
                        </form>

                    </div>
                </div>

            </div>
        </div>
    </div>
@endsection
