<?php

return [
    'admin' => 'Admin',
    'yonetici' => 'Yönetici',
    'mudur' => 'Müdür',
    'booking_manager' => 'Rezervasyon Sorumlusu',
    'fleet_manager' => 'Filo Yöneticisi',
    'user' => 'Kullanıcı',
    'lojistik_personeli' => 'Lojistik Personeli',
    'uretim_personeli' => 'Üretim Personeli',
    'idari_isler_personeli' => 'İdari İşler Personeli',
    'bakim_personeli' => 'Bakım Personeli',
];