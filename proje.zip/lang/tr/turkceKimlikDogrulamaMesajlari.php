<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Kimlik Doğrulama
    |--------------------------------------------------------------------------
    |
    | Aşağıdaki metinler kimlik doğrulama (giriş) sırasında kullanıcılara
    | gösterilebilecek çeşitli mesajları içermektedir. Bu metinleri
    | uygulamanızın gereksinimlerine göre düzenlemekte özgürsünüz.
    |
    */

    'failed'   => 'Girilmiş olan kullanıcı verileri sistemdekiler ile eşleşmemektedir.',
    'password' => 'Girilen şifre yanlış.',
    'throttle' => 'Çok fazla giriş denemesi yapıldı. Lütfen :seconds saniye sonra tekrar deneyiz.',
];
